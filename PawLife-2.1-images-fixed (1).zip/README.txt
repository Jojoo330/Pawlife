PawLife 2.1 offline image fix
Upload index.html AND the entire images folder to the GitHub repository root.
Images are AI-generated photorealistic illustrations cropped from a design mockup, not documentary photographs.
